# PORTDENTS — GitHub Pages Ready

This version keeps the PORTDENTS design and portfolio builder, removes the profile-photo upload/request, and increases the text size in the generated portfolio.

Publish:
Settings → Pages → Deploy from a branch → `main` → `/(root)` → Save.

PDF:
Click **Download PDF** and choose **Save as PDF** in the browser print dialog.
